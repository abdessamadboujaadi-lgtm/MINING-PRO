MINING PRO Simulator — Android Studio starter

Ce dossier contient le CODE SOURCE Android, pas un APK déjà compilé.

Inclus:
- Application Android avec WebView locale.
- Simulation locale du solde (valeurs fictives, sans dépôt ni retrait).
- Emplacement de bannière AdMob.
- Annonce récompensée: le boost de 30 minutes n'est accordé qu'après le callback de récompense AdMob.
- Identifiant AdMob de l'application fourni par le propriétaire.

IMPORTANT — MODE TEST
MainActivity.java contient TEST_ADS = true. L'application utilise les identifiants de test Google pour la bannière et la récompense. C'est volontaire pour éviter de générer des impressions/clics invalides pendant le développement.

Les identifiants de blocs publicitaires réels du compte sont déjà notés dans les commentaires du code:
Banner:   ca-app-pub-6252907986906005/5416800909
Rewarded: ca-app-pub-6252907986906005/8430937516
Ne passez TEST_ADS à false qu'après intégration vérifiée, conformité aux règles AdMob, et préparation à la publication. Ne cliquez jamais sur vos propres annonces.

Pour générer l'APK:
1. Installez Android Studio sur un ordinateur.
2. Ouvrez le dossier MINING_PRO_Android_AdMob avec Android Studio.
3. Attendez la synchronisation Gradle et installez Android SDK Platform 35 si demandé.
4. Choisissez Build > Build Bundle(s) / APK(s) > Build APK(s).
5. L'APK de debug sera généré dans app/build/outputs/apk/debug/.

Limites de cette version:
- Pas d'authentification, serveur, base de données partagée, système de parrainage réel ou panneau admin.
- Les données de simulation sont stockées localement sur le téléphone.
- Le compte AdMob est configuré avec le véritable App ID, mais les blocs publicitaires restent en mode test dans le code.
- Avant toute diffusion publique, vérifier les règles AdMob/Google Play, le consentement UMP si nécessaire, la politique de confidentialité et les exigences de cible Android actuelles.

SDK: com.google.android.gms:play-services-ads:25.5.0.
Références officielles:
https://developers.google.com/admob/android/quick-start
https://developers.google.com/admob/android/banner
https://developers.google.com/admob/android/rewarded

Note SDK (novembre 2026): ce squelette utilise l'ancienne bibliothèque Google Mobile Ads 25.5.0 (encore prise en charge, mais Google recommande désormais GMA Next-Gen). Avant une publication réelle, il faudra envisager la migration vers GMA Next-Gen selon le guide officiel:
https://developers.google.com/admob/android/next-gen/migration

BUILD APK SANS ORDINATEUR (depuis un téléphone Android)
1) Crée un compte GitHub gratuit sur https://github.com/ si tu n'en as pas.
2) Dans GitHub, crée un nouveau dépôt public nommé MINING-PRO-Simulator.
3) Depuis le navigateur du téléphone, ouvre le dépôt, puis Add file > Upload files.
4) Décompresse ce ZIP sur le téléphone et téléverse le CONTENU du dossier MINING_PRO_Android_AdMob (pas le dossier parent) dans le dépôt. Vérifie que build.gradle, settings.gradle, app/ et .github/ sont à la racine du dépôt.
5) Ouvre l'onglet Actions, choisis "Build MINING PRO APK", puis Run workflow.
6) Quand le travail finit en vert, ouvre-le et télécharge l'artefact MINING-PRO-Simulator-debug-APK. Il contient app-debug.apk.
7) Ceci est une APK debug de test, pas une version signée prête pour Google Play.

NOTE: Le projet utilise des identifiants publicitaires de TEST Google. Ne remplace pas TEST_ADS par false avant validation de l'application et vérification des règles AdMob. Les soldes et récompenses restent fictifs; aucune crypto réelle, aucun dépôt ni retrait.
