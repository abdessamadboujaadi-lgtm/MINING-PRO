package com.miningpro.simulator;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.view.Gravity;
import android.view.ViewGroup;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdSize;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.AdError;

public class MainActivity extends Activity {
    // Keep TEST_ADS=true while developing. Never click your own live ads.
    private static final boolean TEST_ADS = true;
    private static final String TEST_BANNER_ID = "ca-app-pub-3940256099942544/6300978111";
    private static final String TEST_REWARDED_ID = "ca-app-pub-3940256099942544/5224354917";
    // Your real AdMob units, to be enabled only after policy/compliance checks:
    // Banner:   ca-app-pub-6252907986906005/5416800909
    // Rewarded: ca-app-pub-6252907986906005/8430937516

    private WebView webView;
    private AdView bannerAd;
    private RewardedAd rewardedAd;
    private boolean rewardEarned = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(0xFF07111F);
        getWindow().setNavigationBarColor(0xFF07111F);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(0xFF07111F);

        webView = new WebView(this);
        webView.setBackgroundColor(0xFF07111F);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new AppBridge(), "MiningApp");
        root.addView(webView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        bannerAd = new AdView(this);
        bannerAd.setAdSize(AdSize.BANNER);
        bannerAd.setAdUnitId(TEST_ADS ? TEST_BANNER_ID : "ca-app-pub-6252907986906005/5416800909");
        LinearLayout adContainer = new LinearLayout(this);
        adContainer.setGravity(Gravity.CENTER);
        adContainer.setBackgroundColor(0xFF0B1728);
        adContainer.addView(bannerAd);
        root.addView(adContainer, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        setContentView(root);
        webView.loadUrl("file:///android_asset/index.html");

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override public void onInitializationComplete(InitializationStatus status) {
                runOnUiThread(() -> {
                    bannerAd.loadAd(new AdRequest.Builder().build());
                    loadRewardedAd();
                });
            }
        });
    }

    private void loadRewardedAd() {
        String adUnit = TEST_ADS ? TEST_REWARDED_ID : "ca-app-pub-6252907986906005/8430937516";
        RewardedAd.load(this, adUnit, new AdRequest.Builder().build(),
                new RewardedAdLoadCallback() {
                    @Override public void onAdLoaded(RewardedAd ad) { rewardedAd = ad; }
                    @Override public void onAdFailedToLoad(LoadAdError error) {
                        rewardedAd = null;
                    }
                });
    }

    private class AppBridge {
        @JavascriptInterface
        public void showRewardedAd() {
            runOnUiThread(() -> {
                if (rewardedAd == null) {
                    Toast.makeText(MainActivity.this, "الإعلان مازال ما واجدش، عاود بعد شوية", Toast.LENGTH_SHORT).show();
                    loadRewardedAd();
                    return;
                }
                rewardEarned = false;
                rewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {
                    @Override public void onAdDismissedFullScreenContent() {
                        rewardedAd = null;
                        loadRewardedAd();
                        if (!rewardEarned) {
                            webView.evaluateJavascript("window.onRewardedAdClosed && window.onRewardedAdClosed(false)", null);
                        }
                    }
                    @Override public void onAdFailedToShowFullScreenContent(AdError error) {
                        rewardedAd = null;
                        loadRewardedAd();
                        Toast.makeText(MainActivity.this, "تعذر عرض الإعلان", Toast.LENGTH_SHORT).show();
                    }
                });
                rewardedAd.show(MainActivity.this, rewardItem -> {
                    rewardEarned = true;
                    webView.evaluateJavascript("window.onRewardedAdClosed && window.onRewardedAdClosed(true)", null);
                });
            });
        }
    }

    @Override public void onPause() {
        if (bannerAd != null) bannerAd.pause();
        super.onPause();
    }

    @Override public void onResume() {
        super.onResume();
        if (bannerAd != null) bannerAd.resume();
    }

    @Override public void onDestroy() {
        if (bannerAd != null) bannerAd.destroy();
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
